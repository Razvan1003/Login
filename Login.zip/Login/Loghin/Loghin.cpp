﻿#include <iostream>
#include <fstream>
using namespace std;

class Temp {
private:
    string userName, Email, password;
    string searchName, searchPass, searchEmail;
    fstream file;

public:
    void login();
    void signUp();
    void forgot();
};

Temp obj;

int main() {
    char choice;
    cout << "\n1- Login";
    cout << "\n2- Sign-Up";
    cout << "\n3- Forgot Password";
    cout << "\n4- Exit";
    cout << "\nEnter your choice: ";
    cin >> choice;

    switch (choice) {
    case '1':
        cin.ignore();
        obj.login();
        break;
    case '2':
        cin.ignore();
        obj.signUp();
        break;
    case '3':
        cin.ignore();
        obj.forgot();
        break;
    case '4':
        return 0;
        break;
    default:
        cout << "Invalid Selection!";
        break;
    }

    return 0;
}

void Temp::signUp() {
    cout << "\nEnter Your User Name :: ";
    cin >> userName;
    cout << "Enter Your Email Address :: ";
    cin >> Email;
    cout << "Enter Your Password :: ";
    cin >> password;

    file.open("loginData.txt", ios::out | ios::app);

    if (file.is_open()) {
        file << userName << "*" << Email << "*" << password << endl;
        file.close();
        cout << "Registration Successful!" << endl;
    }
    else {
        cerr << "Error opening file for writing!" << endl;
    }
}

void Temp::login() {
    cout << "--------LOGIN----------\n";
    cout << "Enter your use name:: ";
    cin >> searchName;
    cout << "Enter your password: ";
    cin >> searchPass;

    file.open("loginData.txt", ios::in);

    while (file >> userName >> Email >> password) {
        if (userName == searchName && password == searchPass) {
            cout << "\nAccount login successful!" << endl;
            cout << "Username :: " << userName << endl;
            cout << "Email :: " << Email << endl;
            return; 
        }
    }

    cout << "Account not found or incorrect credentials!" << endl;
    file.close();
}

void Temp::forgot() {
    cout << "\nEnter your username :: ";
    cin >> searchName;
    cout << "\nEnter your email address :: ";
    cin >> searchEmail;

    file.open("loginData.txt", ios::in);

    while (file >> userName >> Email >> password) {
        if (userName == searchName && Email == searchEmail) {
            cout << "\nAccount found!" << endl;
            cout << "Your password :: " << password << endl;
            return; 
        }
    }

    cout << "Account not found or incorrect email address!" << endl;
    file.close();
}